<?php
/**
 * @package PKWD Auto Page / Category Generator
 */
/*
Plugin Name: Auto Page / Category Creator
Plugin URI: http://www.pkwebdesigns.com.au/plugins/pagegen.zip
Description: Auto page generator!
Version: 1.01
Author: Paul Edward Kruger
Author URI: http://pkwebdesigns.com.au/#About
License: GPLv2 or later
Text Domain: Zastroph
*/



function page_gen(){
    $mr_categories = "Music#Classical and art music traditions*Classical music*Opera|Electronic*Breakbeat*Electro*EDM*Hardstyle*House*Techno*Trance|Folk*Traditional|Popular*Blues*Country*Hip hop*Jazz*Pop*Reggae*R&B|Rock*Alternative*Synth*Metal*Punk|Progressive*Psychedelic";
?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>

<div class="jumbotron">
  <h1 class="display-3">PKWD Auto Page / Category Generator!</h1>
    <p class="lead">This plugin will generate basic pages and / or categories, allowing the user to easily set up their website for the first time. Saving you time!</p>
  <hr class="my-4">
  <p>Designed and built be Paul Edward Kruger, at <a href="http://www.pkwebdesigns.com.au" target="new" >www.pkwebdesigns.com.au</a></p>
  <p class="lead">
    <a class="btn btn-primary btn-lg" href="http://www.pkwebdesigns.com.au" target="new" role="button">Learn more</a>
  </p>
    
<h4>Generate Pages exaample input!</h4>
    <div class="alert alert-info">Home|About|Contact Us|Blog</div>
<h4>Generate Categories example input!</h4>
    <div class="alert alert-info"><?php echo $mr_categories; ?></div>


</div>


<h2>Generate Pages!</h2>
<form name="MR_form" method="post" action="<?php echo str_replace("%7E", "~", $_SERVER[REQUEST_URI]); ?>">
        <input type="text" name="page_titles" value="<?php echo "Home|About|Contact Us|Blog"; ?>" class="form-control" placeholder="Enter page titles" title="Enter page titles" aria-describedby="basic-addon1">
        <input type="submit" name="my_submit" value="Submit Pages"  class="btn btn-success btn-lg">
</form>
<p class="form-control alert alert-info">Please enter page titles in this format: TitleName|TitleName| etc...! Where you seperate page titles with a single | character!!!</p>
<h2>Generate Categories!</h2>
<form name="MR_form1" method="post" action="<?php echo str_replace("%7E", "~", $_SERVER[REQUEST_URI]); ?>">
        <input type="text" name="mr_terms" value="<?php echo $mr_categories; ?>" class="form-control" placeholder="Enter page titles" title="Enter page titles" aria-describedby="basic-addon1">
        <input type="submit" name="my_category" value="Submit Categories"  class="btn btn-success btn-lg">
</form>
<p class="form-control alert alert-info">Please enter categories in this format: Type#Name*Subcat 1*Subcat 2*Subcat 3|Name*Subcat 1|Name*Subcat 1*Subcat 2| etc...! Where type is first, followed immediately by a single # character, as a seperator, the genres name is next, followed by as many sub genres as required. Seperate genre groups with a single | character and Subcats by a single * character!!!</p>
<p class="alert alert-danger">NOTE: Adding any items, will permanently add them to the wordpress server, and they will remain there even if you remove / delete this plugin. You can of course delete them through the standard wordpress functionality. Also note that is will only be possible to edit them via the standard wordpress functionality!</p>

<?php
    
    if( isset( $_POST[ 'my_submit' ] ) ){
//        $types = "Home|About|Contact Us|Blog";
        $i=0;
        $types = explode( "|", $_POST[ 'page_titles' ] );
        foreach( $types as $type ){
            install_events_pg($type, $menu_id, $i );
            $i++;
        }

    }
                    
    if( isset( $_POST[ 'my_category' ] ) ){
        Generate_Categories();
    }
}

//add_shortcode("gen_pages", "page_gen" );
//shortcode is [gen_pages]

//Add Events page on activation:
function install_events_pg( $title, $menu_id, $cnt ){
        $new_page_title = $title;
        $new_page_content = 'Click edit to edit this page!';
        $new_page_template = '';

        $page_check = get_page_by_title($new_page_title);
        if($title=="Contact Us")    $new_page_content .= "<br/><br/>If you wish to use the Contact Form 7, enter the shortcode here. Available <a href='https://wordpress.org/plugins/contact-form-7' target='new'>here</a>. Or get it from the wordpress plugins <a href='".get_dashboard_url()."'>dashboard!</a>";    

//        if($title=="About")    $new_page_content .= include "about.php";
    
        if(!isset($page_check->ID)){
            $new_page = array(
                'post_type' => 'page',
                'post_title' => $new_page_title,
                'post_content' => $new_page_content,
                'post_date' => 0,
                'post_status' => 'publish',
                'post_author' => 1,
                'menu_order' => $cnt,
            );

                $new_page_id = wp_insert_post($new_page);
                if(!empty($new_page_template)){
                        update_post_meta($new_page_id, '_wp_page_template', $new_page_template);
                }
        }

    register_activation_hook(__FILE__, 'install_events_pg');
    
}

function Generate_Categories(){
    if( isset( $_POST[ 'mr_terms' ] ) && $_POST[ 'mr_terms' ] != '' ){
        $types = explode( "#", $_POST[ 'mr_terms' ] );
            
        $main_genre_counter = 0;
        $main_genre_name = "";

        foreach( $types as $type ){
            if($main_genre_counter == 0 ){
                $main_genre_name = $type;
                //see if we can get the base ty1pe
                $base_term = term_exists( $type, 'category', 0 );
                //did we get the bae type
                if ( $base_term == 0 || $base_term == null ) {
                    //not found, so add it
                    wp_insert_term(
                        $type,   // the term 
                        'category', // the taxonomy
                        array(
                            'description' => $type . ' base type',
                            'slug'        => strtolower( $type ),
                            'parent'      => 0,
                        )
                    );
                }
                $main_genre_counter ++;
            }else{
                $base_term = term_exists( $main_genre_name, 'category', 0 );
                //we should now have the base genre type
                if ( $base_term !== 0 && $base_term !== null ) {
                    if( $base_term && isset( $base_term['term_id'] ) ) {
                        //get base iid
                        $base_term_id = $base_term['term_id'];

                        $genres = explode( "|", $type );
                        foreach( $genres as $genre ){
                            $i = 0;
                            $subgenres = explode( "*", $genre );
                            foreach( $subgenres as $subgenre ){
                                if( $i == 0 ){
                                    //check if base genre has this genre group
                                    $parent_term = term_exists( $subgenre, 'category', $base_term_id );
                                    if ( $parent_term == 0 || $parent_term == null ) {
                                        //not found, so add it
                                        wp_insert_term(
                                            $subgenre,   // the term 
                                            'category', // the taxonomy
                                            array(
                                                'description' => $subgenre . ' parent type',
                                                'slug'        => strtolower( $subgenre ),
                                                'parent'      => $base_term_id,
                                            )
                                        );
                                    }

                                    //get parent id, to attach sub types to it
                                    $parent_term = term_exists( $subgenre, 'category', $base_term_id );
                                    if( $parent_term && isset( $parent_term['term_id'] ) ) {
                                        $parent_term_id = $parent_term['term_id'];
                                    }
                                }else{
                                    //check if sub genre exists in this genre group
                                    $sub_term = term_exists( $subgenre, 'category', $parent_term_id );
                                    if ( $sub_term == 0 || $sub_term == null ) {
                                        //not found, so add it
                                        wp_insert_term(
                                            $subgenre,   // the term 
                                            'category', // the taxonomy
                                            array(
                                                'description' => $subgenre . ' type',
                                                'slug'        => strtolower( $subgenre ),
                                                'parent'      => $parent_term_id,
                                            )
                                        );
                                    }
                                }
                                $i++;
                            }
                            $i=0;    
                        }
                    }
                }
            }
        }
    }
}


/** ************************ REGISTER THE TEST PAGE ****************************
 *******************************************************************************
 * Now we just need to define an admin page. For this example, we'll add a top-level
 * menu item to the bottom of the admin menus.
 */
function PKPG_generate_pages(){
    add_menu_page('Page Generator', 'Page Generator', 'activate_plugins', 'pkpg_list_test', 'page_gen');
} add_action('admin_menu', 'PKPG_generate_pages');

?>